# MOF–nanoparticle scattering handoff

Start with [START_HERE.md](START_HERE.md). Give the local coding agent [LOCAL_AGENT_PROMPT.md](LOCAL_AGENT_PROMPT.md); keep this entire folder available to it.

The implemented v0.3 code is in `mof_debye_lab/`. Read
`mof_debye_lab/MODE_GUIDE.md`, `mof_debye_lab/R07_GUIDE.md` and `R07_REPORT.md`
for current behavior. `COMPLETION_REPORT.md` preserves the v0.2 delivery record.
The original handoff specifications and manifests describe v0.1; intentional
source changes are recorded separately. The original ZIP, historical results,
logs and `qa/` preserve baseline evidence. New runs are in `local_runs/`.
