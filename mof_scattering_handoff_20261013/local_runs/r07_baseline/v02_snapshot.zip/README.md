# MOF–nanoparticle scattering handoff

Start with [START_HERE.md](START_HERE.md). Give the local coding agent [LOCAL_AGENT_PROMPT.md](LOCAL_AGENT_PROMPT.md); keep this entire folder available to it.

The implemented v0.2 code is in `mof_debye_lab/`. Read
`mof_debye_lab/MODE_GUIDE.md` and `COMPLETION_REPORT.md` for current behavior.
The original handoff specifications and manifests describe v0.1; intentional
source changes are recorded separately. The original ZIP, historical results,
logs and `qa/` preserve baseline evidence. New runs are in `local_runs/`.
