# MOF–nanoparticle scattering handoff

Start with [START_HERE.md](START_HERE.md). Give the local coding agent [LOCAL_AGENT_PROMPT.md](LOCAL_AGENT_PROMPT.md); keep this entire folder available to it.

The complete unchanged prototype is in `mof_debye_lab/`. The three-mode specification, development tasks, and fresh verification are alongside it.
