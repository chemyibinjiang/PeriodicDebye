#!/usr/bin/env python3
"""OPTIONAL: test the actually installed public API. NOT EXECUTED in this sandbox.
This does not import the vendored kernel. Install .[external] first on a connected
machine. Per-species one-atom outputs calibrate the package's native form factors
and overall scale before comparing atom pairs to an independent Debye sum.
"""
from __future__ import annotations
import argparse,importlib.metadata,json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import numpy as np
from scipy.spatial.distance import pdist,cdist
import torch
from mofdebye.fixtures import finite_host
from mofdebye.core import weighted_sinc_sum


def main():
    try:
        from debyecalculator import DebyeCalculator
    except ImportError as exc:
        raise SystemExit("Full package not installed. On a connected machine run: pip install '.[external]'\n"
                         "The bundled source-kernel tests are a different, explicitly labelled test.") from exc
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    ap.add_argument('--out',type=Path,default=Path('results/installed_package.json'))
    args=ap.parse_args()
    if args.device=='cuda' and not torch.cuda.is_available(): raise SystemExit('CUDA is unavailable.')
    torch.set_num_threads(1)
    cfg=dict(qmin=.15,qmax=8.,qstep=.026,biso=0.,device=args.device,
             radiation_type='xray',dtype=torch.float64,num_threads=1)
    calculators={mode:DebyeCalculator(**cfg,pair_sum=mode) for mode in ('direct','grid')}
    rows=[]
    for size in (2,3):
        host,*_=finite_host((size,size,size),n_basis=24)
        results={};times={}
        for mode,calc in calculators.items():
            stamp=time.perf_counter()
            q,y=calc.iq((list(host.elements),torch.tensor(np.array(host.xyz),dtype=torch.float64)))
            if args.device=='cuda': torch.cuda.synchronize()
            times[mode]=time.perf_counter()-stamp;results[mode]=np.asarray(y)
        species=sorted(set(host.elements));labels=np.asarray(host.elements)
        # sqrt(one-atom intensity) incorporates the package's native scale/factors.
        atomic={}
        for el in species:
            q,single=calculators['direct'].iq(([el],torch.zeros((1,3),dtype=torch.float64)))
            if np.any(single<0): raise AssertionError('Negative one-atom intensity.')
            atomic[el]=np.sqrt(single)
        independent=np.zeros(len(q))
        for k,a in enumerate(species):
            xa=host.xyz[labels==a]
            independent+=len(xa)*atomic[a]**2+2*atomic[a]**2*weighted_sinc_sum(pdist(xa),q)
            for b in species[k+1:]:
                independent+=2*atomic[a]*atomic[b]*weighted_sinc_sum(cdist(xa,host.xyz[labels==b]).ravel(),q)
        errors={mode:float(np.max(abs(y-independent))/np.max(abs(independent))) for mode,y in results.items()}
        assert max(errors.values())<1e-7,errors
        rows.append(dict(n_atoms=len(host),seconds=times,relative_max_errors=errors))
    result=dict(status='executed_installed_public_api',version=importlib.metadata.version('debyecalculator'),
                device=args.device,rows=rows,
                normalisation='package-native scale calibrated using one-atom outputs; factors from installed package')
    args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
