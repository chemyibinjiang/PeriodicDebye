"""Research prototype for finite MOF/guest Debye scattering."""
from .core import AtomCloud, direct_iq, cross_iq, pair_decomposition, upstream_kernel_iq
__version__ = '0.1.0'
