"""Independent prototype: FFT finite-shape autocorrelation and lattice-grouped Debye.
This is new project code, NOT a feature attributed to the tested external kernel.
It preserves complete identical unit cells; arbitrary atom-level surface cutting
and surface relaxation require separate treatment.
"""
import numpy as np
from scipy.signal import fftconvolve
from .core import form_factors, weighted_sinc_sum, validate_q

def shape_autocorrelation(mask):
    mask = np.asarray(mask)
    if mask.ndim != 3 or not np.all(np.isin(mask, (0, 1))) or not np.any(mask):
        raise ValueError('mask must be a nonempty three-dimensional binary array.')
    # Full LINEAR correlation: fftconvolve pads internally; there is no periodic wrap.
    floating = fftconvolve(mask.astype(float), mask[::-1, ::-1, ::-1].astype(float), mode='full')
    counts = np.rint(floating).astype(np.int64)
    if np.max(np.abs(floating-counts)) > 1e-5 or np.any(counts < 0):
        raise ArithmeticError('FFT correlation rounding did not produce valid pair counts.')
    if counts.sum() != int(mask.sum())**2 or counts[tuple(np.array(mask.shape)-1)] != mask.sum():
        raise ArithmeticError('Finite-shape pair-count identities failed.')
    indices = np.argwhere(counts > 0)
    translations = indices - (np.array(mask.shape) - 1)
    return translations, counts[tuple(indices.T)]

def lattice_grouped_iq(basis, cell_vectors_A, mask, q):
    """Exact rearrangement of the full Debye sum (up to floating-point arithmetic).
    cell_vectors_A has lattice vectors as rows; basis coordinates are Cartesian.
    No spherical shape average or reciprocal-space orientation sampling is used.
    """
    q = validate_q(q)
    cell = np.asarray(cell_vectors_A, dtype=float)
    if cell.shape != (3, 3) or not np.isfinite(cell).all() or abs(np.linalg.det(cell)) < 1e-12:
        raise ValueError('cell_vectors_A must be a nonsingular finite 3-by-3 matrix.')
    translations, multiplicities = shape_autocorrelation(mask)
    vectors = translations @ cell
    f = form_factors(basis.elements, q); species = list(f)
    labels = np.asarray(basis.elements)
    out = np.zeros(len(q))
    for k, a in enumerate(species):
        xa = basis.xyz[labels == a]
        for b in species[k:]:
            xb = basis.xyz[labels == b]
            # Same-species ordered pairs include the self terms at T=0, alpha=beta.
            # Unlike-species reverse pairs contribute identically after summing +/-T.
            factor = 1 if a == b else 2
            for ra in xa:
                for rb in xb:
                    d = np.linalg.norm(vectors + ra - rb, axis=1)
                    out += factor * f[a] * f[b] * weighted_sinc_sum(d, q, multiplicities)
    return out
